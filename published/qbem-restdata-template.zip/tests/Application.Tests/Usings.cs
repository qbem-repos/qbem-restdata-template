global using Xunit;
global using QBem.RestData.Toolkit.Application.Usecases;
global using QBem.RestData.Toolkit.Domain.Abstractions;
global using WebApi.Entities;