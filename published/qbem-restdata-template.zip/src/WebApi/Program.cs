using QBem.RestData.Toolkit.Gateway.WebApi;
using WebApi.Entities;

WebApiFactory.AddRestData<$ext_safeprojectname$>(args);